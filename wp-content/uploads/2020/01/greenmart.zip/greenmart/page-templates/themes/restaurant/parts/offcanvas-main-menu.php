<div id="tbay-offcanvas-main" class="hidden-xs hidden-sm tbay-offcanvas-main verticle-menu"> 
    <div class="tbay-offcanvas-body">
        <div class="offcanvas-head">
        	<?php echo esc_html('CLOSE', 'greenmart'); ?>
            <button type="button" class="btn btn-toggle-canvas btn-danger" data-toggle="offcanvas">x</button>
        </div>

        <?php greenmart_tbay_get_page_templates_parts('nav-vertical'); ?>

    </div>
</div>