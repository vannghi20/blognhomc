<?php 

    $enable_reserve_table  = greenmart_tbay_get_config('enable_reserve_table', false);
    $_id = greenmart_tbay_random_key();

    if( !$enable_reserve_table ) {
        return;
    } else {
        $button       = greenmart_tbay_get_config('rtb_button', esc_html__('Reserve Table', 'greenmart'));
        $title        = greenmart_tbay_get_config('rtb_title');
        $des          = greenmart_tbay_get_config('rtb_descreption');
    }

?>

<?php if( !empty($button) ) : ?>

    <div class="reserve-table-popup">
        <button type="button" class="btn-reserve-table-top" data-toggle="modal" data-target="#reserve-table-<?php echo esc_attr($_id); ?>">
           <i class="icofont icofont-ui-calendar"></i><?php echo trim($button); ?>
        </button>
    </div>

    <div class="modal fade reserve-table-form-modal" id="reserve-table-<?php echo esc_attr($_id); ?>" tabindex="-1" role="dialog" aria-labelledby="searchformlable-<?php echo esc_attr($_id); ?>">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body widget center">
                    <?php if( (isset($title) && $title)  ): ?>
                        <h3 class="widget-title">
                            <?php if ( isset($title) && $title ): ?>
                                <span><?php echo esc_html( $title ); ?></span>
                            <?php endif; ?>
                        </h3>
                        <?php if ( isset($des) && $des ): ?>
                            <span class="description"><?php echo esc_html($des); ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
  			       <?php echo do_shortcode('[booking-form]'); ?>
                </div>
            </div>
        </div>
    </div>

<?php endif;?>
