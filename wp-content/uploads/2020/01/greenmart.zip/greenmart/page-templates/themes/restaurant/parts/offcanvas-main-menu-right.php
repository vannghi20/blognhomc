<div id="tbay-offcanvas-main" class="hidden-sm hidden-xs tbay-offcanvas-main verticle-menu right"> 
    <div class="tbay-offcanvas-body">
        <div class="offcanvas-head">
        	<a><?php echo esc_html('CLOSE', 'greenmart'); ?></a>
            <button type="button" class="btn btn-toggle-canvas btn-danger" data-toggle="offcanvas">x</button>
        </div>

        <?php greenmart_tbay_get_page_templates_parts('nav-vertical'); ?>

    </div>
</div>