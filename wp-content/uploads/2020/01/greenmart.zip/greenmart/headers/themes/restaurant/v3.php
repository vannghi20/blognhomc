<?php $_id = greenmart_tbay_random_key(); ?>
<?php greenmart_tbay_get_page_templates_parts('offcanvas-main-menu-right'); ?>
<div class="modal fade search-form-modal" id="searchformshow-<?php echo esc_attr($_id); ?>" tabindex="-1" role="dialog" aria-labelledby="searchformlable-<?php echo esc_attr($_id); ?>">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="searchformlable-<?php echo esc_attr($_id); ?>"><?php esc_html_e('Search form', 'greenmart'); ?></h4>
      </div>
      <div class="modal-body">
			<?php greenmart_tbay_get_page_templates_parts( 'productsearchform' ); ?>
      </div>
    </div>
  </div>
</div>


<header id="tbay-header" class="site-header header-v3 hidden-sm hidden-xs <?php echo (greenmart_tbay_get_config('keep_header', false) ? 'main-sticky-header' : ''); ?>">
    <div class="container-fluid">
        <div class="row">
            <div class="header-left col-md-6">
                <!-- LOGO -->
            	<div class="logo-white">
                    <?php greenmart_tbay_get_page_templates_parts('logo','white'); ?> 
                </div>
                <div class="logo-stick">
                    <?php greenmart_tbay_get_page_templates_parts('logo'); ?> 
                </div>
            </div>
	        <div class="header-right col-md-6">
		    	<!-- search-form-modal -->
				<div id="search-form-modal-<?php echo esc_attr($_id); ?>" class="search-popup">
					<button type="button" class="btn-search-totop" data-toggle="modal" data-target="#searchformshow-<?php echo esc_attr($_id); ?>">
					  <i class="icofont icofont-search-1"></i>
					</button>
				</div>
                <!-- cart -->
                <div class="top-cart hidden-xs">
                    <?php greenmart_tbay_get_woocommerce_mini_cart(); ?>
                </div>
                 <!-- Mainmenu -->
                <div class="tbay-mainmenu">
                    <div class="topbar-mobile">
                        <button data-toggle="offcanvas" class="btn btn-sm btn-offcanvas" type="button">
                            <i class="icofont icofont-navigation-menu"></i>
                        </button>
                    </div>
                </div>
              				
	        </div>
        </div>
    </div>
</header>