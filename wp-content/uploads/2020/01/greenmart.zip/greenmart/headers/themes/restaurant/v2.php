<?php greenmart_tbay_get_page_templates_parts('offcanvas-main-menu');

$_id = greenmart_tbay_random_key();

?>
<header id="tbay-header" class="site-header header-v2 hidden-sm hidden-xs <?php echo (greenmart_tbay_get_config('keep_header') ? 'main-sticky-header' : ''); ?>" role="banner">
	<div class="container-fluid">
    	<div class="row">
            <!-- Mainmenu -->		          	
			<div class="tbay-mainmenu col-md-3">
				<div class="topbar-mobile">
					<button data-toggle="offcanvas" class="btn btn-sm btn-offcanvas" type="button">
					   <i class="icofont icofont-navigation-menu"></i>
					   <?php echo esc_attr('MENU','greenmart'); ?>
					</button>
				</div>
			</div>			
			<!-- social -->
			<div class="not-sticky header-center col-md-6">	
				<?php if(is_active_sidebar('topbar-social-v2')) : ?>
				<?php dynamic_sidebar('topbar-social-v2'); ?>
				<?php endif;?>
            </div>
            <div class="col-md-6 sticky-logo">
				<?php greenmart_tbay_get_page_templates_parts( 'logo' ); ?>
    		</div>
            <!--top cart right-->					
			<div class="header-right col-md-3">						
				
				<div id="search-form-horizontal-<?php echo esc_attr($_id); ?>" class="search-horizontal">
					<button type="button" class="btn-search-totop">
					  	<i class="icofont icofont-search"></i>
					</button>
					<div class="container-search-horizontal">
						<div class="search-horizontal-wrapper">
						    <div class="search-horizontal-content">
							    <?php greenmart_tbay_get_page_templates_parts( 'productsearchform', 'horizontal'); ?>
							</div>
						</div>
			        </div>
				</div>
				<div class="top-cart hidden-xs">
					<?php greenmart_tbay_get_woocommerce_mini_cart(); ?>
				</div>
			</div>
		</div>
    </div>
</header>