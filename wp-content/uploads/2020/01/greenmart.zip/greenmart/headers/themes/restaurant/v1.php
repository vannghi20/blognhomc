<?php 
	$_id = greenmart_tbay_random_key(); 
?>
<header id="tbay-header" class="site-header header-default header-v1 hidden-sm hidden-xs <?php echo (greenmart_tbay_get_config('keep_header') ? 'main-sticky-header' : ''); ?>" role="banner">
	<div id="tbay-topbar" class="tbay-topbar hidden-sm hidden-xs">
	    <div class="topbar-inner clearfix">
            <div class="container-fluid">
                <div class="row">
					<div class="col-sm-12 top-right">
						
						<?php if ( greenmart_tbay_get_config('header_login') ) { ?>
							<?php greenmart_tbay_get_page_templates_parts( 'topbar-account' ); ?>
						<?php } ?>
						<?php if ( !(defined('GREENMART_WOOCOMMERCE_CATALOG_MODE_ACTIVED') && GREENMART_WOOCOMMERCE_CATALOG_MODE_ACTIVED) && defined('GREENMART_WOOCOMMERCE_ACTIVED') && GREENMART_WOOCOMMERCE_ACTIVED ): ?>	
						<?php endif; ?>
						
						<?php
							if( class_exists( 'WOOCS' ) ) {
								wp_enqueue_style('sumoselect');
								wp_enqueue_script('jquery-sumoselect');	?>
						<div class="tbay-currency">
							<?php
								echo do_shortcode( '[woocs]' );
							?>
						</div>
						<?php } ?>

						<?php if(is_active_sidebar('top-info')) : ?>
						<div>
							<?php dynamic_sidebar('top-info'); ?>
						</div>
						<?php endif;?>
					</div>
                </div>	
            </div>
	    </div>
	</div>
	<div class="header-main">
		<div class="container-fluid">
			<div class="row">
			    <!-- LOGO -->
			    <div class="col-md-2 logo-in-theme">
					<?php greenmart_tbay_get_page_templates_parts( 'logo' ); ?>
			    </div>
			    
			    <div class="main-nav col-md-10">
			    	<!-- Main Menu-->
				    <div id="tbay-mainmenu" class="tbay-mainmenu hidden-xs hidden-sm">	         
						<?php greenmart_tbay_get_page_templates_parts( 'nav' ); ?>	
				    </div>
				    <!-- SEARCH -->
				    <?php 

				    $_id = greenmart_tbay_random_key(); 
				    ?>
				    <div id="search-form-horizontal-<?php echo esc_attr($_id); ?>" class="search-horizontal">
						<button type="button" class="btn-search-totop">
						  	<i class="icofont icofont-search"></i>
						</button>
						<div class="container-search-horizontal">
							<div class="search-horizontal-wrapper">
							    <div class="search-horizontal-content">
								    <?php greenmart_tbay_get_page_templates_parts( 'productsearchform', 'horizontal'); ?>
								</div>
							</div>
						</div>
					</div>
				    <!-- Cart -->
					<div class="top-cart hidden-xs">					
						<?php greenmart_tbay_get_woocommerce_mini_cart(); ?>
					</div>
			    	<!-- Reserve Table -->	      			    
					<div class="reserve-table hidden-sm hidden-xs">
						<?php greenmart_tbay_get_page_templates_parts( 'reserve-table' ); ?>
				    </div>    
				</div>
			</div>
		</div>
	</div>
</header>